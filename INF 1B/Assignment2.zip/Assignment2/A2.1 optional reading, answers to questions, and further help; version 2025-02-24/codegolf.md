# About the CodeGolf website #

This is document version 1, dated 2025-02-24.

The source of challenges for this assignment is a website called
[CodeGolf.](https://codegolf.stackexchange.com/ "CodeGolf") That
website is all about competitive writing of source code that is as
short as possible: the shortest code wins just as in real golf where the
lowest "score" wins. 

**You are not playing CodeGolf for this assignment.** The
CodeGolf website is serving as a resource for challenges and for
authentic (rather than artificial) examples of how to explain a
program design. The details about edge cases and corner cases also
serve to teach you how tightly defined software must be, even for
relatively small programs.

The answers on CodeGolf have been written by highly skilled specialist
programmers. We don't expect you to be able to produce such solutions.
Some answers also don't embody best software engineering practices
(i.e., comprehensibility) precisely because they aim to be short. 
Having said that, the algorithms and solutions in some answers are
something to aspire to because they are elegant and insightful. They
show how some problems can be reduced to a simplified state or
representation (which can also make the algorithm more efficient).
Most importantly for you at this stage is appreciating that some of
the explanations of the implementations are models of how to describe
code properly.

These are the aspects of CodeGolf we do want you to absorb:

1. the ability the describe code effectively;
2. identifying and coping with edge cases and corner cases;
3. the ability to reduce a problem into manageable pieces;
4. the intelligent and effective use of a programming language's
   built-in features.

<STYLE>
* { /* Don't leave any empty lines or IntelliJ might not render correctly */
  /* Text size */
  font-size:   1.1rem;
  /*font-size:   1.2rem;*/
  /* Zenburn dark theme */
  background-color: #2A252A;
  color:            #D5DAD5;
  /* One Dark theme */
  /*background-color: #282C34;
  color:            #ABB2BF;*/
  /* white-ish on dull blue-ish */
  /*background-color: DarkSlateGray;
    color:            AntiqueWhite;*/
  /* white on black */
  /*background-color: black;
  color: white;*/
  /* black on white */
  /*background-color: white;
  color: black;*/
  /* nearly black on bright yellow */
  /*background-color: #FFFFAA;
  color:            #080808;*/
  /* black on bright blue */  
  /*background-color: #99CCFF;
  color:            black;*/
}
body {
  /* width of the text column */
  width: 80%;
  /* line spacing */
  line-height: 180%;
  /*line-height: 200%;*/
  /* Font styles: */
  /* Default sans serif */
  /*font-family: sans-serif;*/
  /* Default serif */
  font-family: serif;
  /* Specific font with generic fall-back */
  /* font-family: "Calibri Light", sans-serif; */
  /*font-family: "OpenDyslexic", sans-serif;*/
}
pre,
code,
pre code {
  /* line spacing */
  line-height: 150%;
  /* Default monospace */
  font-family: monospace;
  /* Specific fixed-width font with generic fall-back */
  /*font-family: "Consolas", monospace;*/
  /*font-family: "OpenDyslexicMono", monospace;*/
}
ol,
ol ol,
ol ol ol { /* Nested lists all use decimal numbering */
  list-style-type: decimal;
}
em {
  /* if you want underlining instead of italics */
  /*font-style: normal;
  border-bottom-style: solid;
  border-bottom-width: 1px;
  padding-bottom:      2px;*/
  text-decoration-skip-ink: auto;
}
h2 { /* Put a horizontal line above major headings to assist screen viewing */
  border-top:  1px solid #D5DAD5;
  margin-top:  80px;
  padding-top: 20px;
  }
</STYLE>